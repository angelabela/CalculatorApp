package com.usermanager;

// WebView entry point placeholder
public class MainActivity {
}
