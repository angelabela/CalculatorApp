UserManagerAPK GitHub Android build project.
