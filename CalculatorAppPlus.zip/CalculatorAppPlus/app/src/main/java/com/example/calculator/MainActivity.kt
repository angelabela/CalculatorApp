package com.example.calculator

import android.content.Context
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

data class HistoryItem(val expression: String, val result: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CalculatorApp() }
    }
}

@Composable
fun CalculatorApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("calculator", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("0") }
    var justEvaluated by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    var showHistory by remember { mutableStateOf(false) }

    val scheme = if (dark) darkColorScheme() else lightColorScheme()

    fun vibrate() {
        val vibrator = if (android.os.Build.VERSION.SDK_INT >= 31) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        if (vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    fun update() {
        result = try {
            formatNumber(evaluate(expression))
        } catch (_: Exception) {
            if (expression.isNotEmpty()) "…" else "0"
        }
    }

    fun press(key: String) {
        vibrate()
        when (key) {
            "AC" -> { expression = ""; result = "0"; justEvaluated = false }
            "⌫" -> {
                if (!justEvaluated) expression = expression.dropLast(1)
                update()
            }
            "=" -> {
                try {
                    val old = expression
                    val r = formatNumber(evaluate(expression))
                    result = r
                    if (old.isNotBlank()) {
                        history = (listOf(HistoryItem(old, r)) + history).take(30)
                        saveHistory(prefs, history)
                    }
                    expression = r
                    justEvaluated = true
                } catch (_: Exception) { result = "错误" }
            }
            "+", "−", "×", "÷" -> {
                if (justEvaluated) justEvaluated = false
                expression = if (expression.isNotEmpty() && expression.last() in "+−×÷")
                    expression.dropLast(1) + key else expression + key
                update()
            }
            "." -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                val current = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!current.contains(".")) expression += "."
                update()
            }
            "%" -> {
                try {
                    expression = formatNumber(evaluate(expression) / 100.0)
                    result = expression
                    justEvaluated = true
                } catch (_: Exception) {}
            }
            else -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                expression += key
                update()
            }
        }
    }

    MaterialTheme(colorScheme = scheme) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { showHistory = true }) { Text("历史") }
                    TextButton(onClick = {
                        dark = !dark
                        prefs.edit().putBoolean("dark", dark).apply()
                    }) { Text(if (dark) "☀ 浅色" else "☾ 深色") }
                }

                Column(
                    Modifier.fillMaxWidth().padding(bottom = 18.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        if (expression.isEmpty()) "" else expression,
                        fontSize = 28.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        result,
                        fontSize = 52.sp,
                        fontWeight = FontWeight.Light,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1
                    )
                }

                val keys = listOf(
                    listOf("AC", "⌫", "%", "÷"),
                    listOf("7", "8", "9", "×"),
                    listOf("4", "5", "6", "−"),
                    listOf("1", "2", "3", "+"),
                    listOf("0", ".", "=")
                )

                keys.forEachIndexed { rowIndex, row ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        row.forEach { key ->
                            val weight = if (rowIndex == 4 && key == "0") 2f else 1f
                            val op = key in listOf("÷", "×", "−", "+", "=")
                            val action = key in listOf("AC", "⌫", "%")
                            CalcKey(
                                key,
                                Modifier.weight(weight).aspectRatio(if (weight == 2f) 2f else 1f),
                                when {
                                    key == "=" -> MaterialTheme.colorScheme.primary
                                    op -> MaterialTheme.colorScheme.secondary
                                    action -> MaterialTheme.colorScheme.surfaceVariant
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                },
                                if (key == "=" || op) Color.White else MaterialTheme.colorScheme.onSurface,
                                { press(key) }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }

            if (showHistory) {
                HistoryDialog(
                    history = history,
                    onDismiss = { showHistory = false },
                    onClear = {
                        history = emptyList()
                        saveHistory(prefs, history)
                    },
                    onPick = {
                        expression = it
                        justEvaluated = false
                        update()
                        showHistory = false
                    }
                )
            }
        }
    }
}

@Composable
fun CalcKey(text: String, modifier: Modifier, bg: Color, fg: Color, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clip(CircleShape),
        color = bg,
        onClick = onClick
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text, fontSize = 25.sp, color = fg)
        }
    }
}

@Composable
fun HistoryDialog(
    history: List<HistoryItem>,
    onDismiss: () -> Unit,
    onClear: () -> Unit,
    onPick: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("计算历史")
                TextButton(onClick = onClear) { Text("清空") }
            }
        },
        text = {
            if (history.isEmpty()) {
                Text("暂无计算记录")
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    history.take(12).forEach {
                        Column(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onPick(it.expression) }
                                .padding(10.dp)
                        ) {
                            Text(it.expression, fontSize = 15.sp)
                            Text("= ${it.result}", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("关闭") } }
    )
}

private fun saveHistory(prefs: android.content.SharedPreferences, list: List<HistoryItem>) {
    prefs.edit().putString(
        "history",
        list.joinToString("\n") { "${it.expression}|||${it.result}" }
    ).apply()
}

private fun loadHistory(prefs: android.content.SharedPreferences): List<HistoryItem> =
    prefs.getString("history", "")!!
        .split("\n")
        .filter { it.contains("|||") }
        .map {
            val p = it.split("|||", limit = 2)
            HistoryItem(p[0], p[1])
        }

private fun formatNumber(v: Double): String {
    if (!v.isFinite()) return "错误"
    if (abs(v) < 1e-10) return "0"
    return if (v % 1.0 == 0.0) v.toLong().toString()
    else "%.10f".format(v).trimEnd('0').trimEnd('.')
}

private fun evaluate(input: String): Double {
    if (input.isBlank()) return 0.0
    val s = input.replace("×", "*").replace("÷", "/").replace("−", "-")
    if (s.last() in "+-*/.") throw IllegalArgumentException()
    val nums = mutableListOf<Double>()
    val ops = mutableListOf<Char>()
    var i = 0
    fun prec(c: Char) = if (c == '*' || c == '/') 2 else 1
    fun applyTop() {
        val b = nums.removeAt(nums.lastIndex)
        val a = nums.removeAt(nums.lastIndex)
        when (val op = ops.removeAt(ops.lastIndex)) {
            '+' -> nums += a + b
            '-' -> nums += a - b
            '*' -> nums += a * b
            '/' -> nums += if (b != 0.0) a / b else throw ArithmeticException()
            else -> error(op)
        }
    }
    while (i < s.length) {
        val start = i
        if (s[i] == '-' && (i == 0 || s[i - 1] in "+-*/")) i++
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (i == start) throw IllegalArgumentException()
        nums += s.substring(start, i).toDouble()
        if (i < s.length) {
            val op = s[i++]
            while (ops.isNotEmpty() && prec(ops.last()) >= prec(op)) applyTop()
            ops += op
        }
    }
    while (ops.isNotEmpty()) applyTop()
    return nums.single()
}
