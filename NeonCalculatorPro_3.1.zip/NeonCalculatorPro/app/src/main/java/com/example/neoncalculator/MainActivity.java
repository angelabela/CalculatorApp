package com.example.neoncalculator;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import android.text.TextUtils;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(10, 12, 20));
        w.setNavigationBarColor(Color.rgb(10, 12, 20));
        if (Build.VERSION.SDK_INT >= 23) w.getDecorView().setSystemUiVisibility(0);
        setContentView(new CalculatorView(this));
    }
}

class CalculatorView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String[] keys = {"AC","⌫","%","÷","7","8","9","×","4","5","6","−","1","2","3","+","±","0",".","="};
    private String value = "0", expr = "", preview = "";
    private boolean evaluated = false, tealTheme = false, vibration = true;
    private int downKey = -1;
    private final ArrayList<String> history = new ArrayList<>();
    private final SharedPreferences sp;
    private float den;

    CalculatorView(Context c) {
        super(c);
        den = getResources().getDisplayMetrics().density;
        setFocusable(true);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        sp = c.getSharedPreferences("calculator_history", Context.MODE_PRIVATE);
        String saved = sp.getString("items", "");
        if (!TextUtils.isEmpty(saved)) history.addAll(Arrays.asList(saved.split("\\n")));
        vibration = sp.getBoolean("vibration", true);
    }

    private float d(float x) { return x * den; }
    private int accent() { return tealTheme ? Color.rgb(56, 210, 200) : Color.rgb(154, 111, 255); }
    private int accent2() { return tealTheme ? Color.rgb(31, 145, 170) : Color.rgb(108, 72, 190); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w=getWidth(), h=getHeight();
        drawBackground(c,w,h);

        float side=d(16);
        // Modern header
        p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(d(21)); p.setColor(Color.WHITE);
        c.drawText("CALC",side,d(34),p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(d(10)); p.setColor(Color.rgb(143,150,173));
        c.drawText("SMART CALCULATOR",side,d(51),p);
        drawTopButton(c,w-d(112),d(16),w-d(62),d(50),"⚙");
        drawTopButton(c,w-d(56),d(16),w-d(16),d(50),tealTheme?"◐":"◑");

        // Large display area
        float top=d(66), bottom=d(292), left=side, right=w-side;
        roundPanel(c,left,top,right,bottom,d(25),Color.rgb(20,23,38),Color.rgb(49,55,78));
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(d(14)); p.setColor(Color.rgb(132,140,163));
        String shownExpr=expr.isEmpty()?"Ready":expr;
        if(shownExpr.length()>48) shownExpr="…"+shownExpr.substring(shownExpr.length()-47);
        c.drawText(shownExpr,left+d(20),top+d(34),p);

        String shown=value;
        float valueSize=shown.length()>15?29:shown.length()>10?35:48;
        p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(d(valueSize)); p.setColor(Color.WHITE);
        if(shown.length()>18) shown="…"+shown.substring(shown.length()-17);
        float vw=p.measureText(shown);
        c.drawText(shown,right-d(20)-vw,top+d(116),p);
        if(!preview.isEmpty()){
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(d(14)); p.setColor(accent());
            String pv="≈ "+preview; float pw=p.measureText(pv); c.drawText(pv,right-d(20)-pw,bottom-d(27),p);
        }
        drawSmallButton(c,left+d(18),bottom-d(54),left+d(104),bottom-d(18),"分享");
        drawSmallButton(c,right-d(104),bottom-d(54),right-d(18),bottom-d(18),"历史");

        // Keypad occupies lower portion
        float gap=d(9);
        float startY=d(307);
        float available=h-startY-d(18);
        float bh=Math.min(d(61),(available-gap*4)/5f);
        float bw=(w-d(32)-gap*3)/4f;
        for(int i=0;i<20;i++){
            int row=i/4,col=i%4;
            float x=side+col*(bw+gap), y=startY+row*(bh+gap);
            drawKey(c,x,y,x+bw,y+bh,keys[i],i);
        }
    }

    private void drawBackground(Canvas c,int w,int h){
        int bg=tealTheme?Color.rgb(8,15,22):Color.rgb(10,10,18);
        c.drawColor(bg);
        p.setShader(new LinearGradient(0,0,w,h,tealTheme?Color.rgb(10,29,38):Color.rgb(25,17,43),bg,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        p.setColor(tealTheme?0x1028cfc5:0x12155fd0); c.drawCircle(w-d(12),h-d(8),d(145),p);
        p.setColor(tealTheme?0x0c2d8f9f:0x0c8b42d0); c.drawCircle(d(8),d(130),d(90),p);
    }

    private void roundPanel(Canvas c,float l,float t,float r,float b,float rad,int fill,int edge){
        p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(l,t,r,b,rad,rad,p);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1)); stroke.setColor(edge); c.drawRoundRect(l,t,r,b,rad,rad,stroke);
    }

    private void drawTopButton(Canvas c,float l,float t,float r,float b,String s){
        roundPanel(c,l,t,r,b,d(15),tealTheme?Color.rgb(18,42,48):Color.rgb(30,25,47),Color.rgb(55,62,84));
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(d(16)); p.setColor(Color.WHITE);
        c.drawText(s,(l+r)/2,(t+b)/2+d(6),p); p.setTextAlign(Paint.Align.LEFT);
    }
    private void drawSmallButton(Canvas c,float l,float t,float r,float b,String s){
        roundPanel(c,l,t,r,b,d(14),tealTheme?Color.rgb(17,48,52):Color.rgb(38,28,56),Color.rgb(67,75,101));
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(d(12)); p.setColor(Color.WHITE);
        c.drawText(s,(l+r)/2,(t+b)/2+d(4),p); p.setTextAlign(Paint.Align.LEFT);
    }
    private void drawKey(Canvas c,float l,float t,float r,float b,String s,int idx){
        boolean op=idx%4==3, equals=s.equals("="), danger=s.equals("AC")||s.equals("⌫");
        int fill=Color.rgb(23,27,45), edge=Color.rgb(52,59,83);
        if(op){fill=tealTheme?Color.rgb(16,49,56):Color.rgb(42,29,62);edge=accent();}
        if(equals){fill=accent2();edge=accent();}
        if(danger){fill=Color.rgb(47,29,45);edge=Color.rgb(174,86,143);}
        if(idx==downKey){fill=Color.rgb(Math.min(255,Color.red(fill)+22),Math.min(255,Color.green(fill)+22),Math.min(255,Color.blue(fill)+22));}
        roundPanel(c,l,t,r,b,d(19),fill,edge);
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(d(s.equals("=")?24:20)); p.setColor(Color.WHITE);
        c.drawText(s,(l+r)/2,(t+b)/2+d(7),p); p.setTextAlign(Paint.Align.LEFT);
    }

    private int hit(float x,float y){
        int w=getWidth(),h=getHeight(); float gap=d(9),startY=d(307),available=h-startY-d(18),bh=Math.min(d(61),(available-gap*4)/5f),bw=(w-d(32)-gap*3)/4f;
        for(int i=0;i<20;i++){int row=i/4,col=i%4;float l=d(16)+col*(bw+gap),t=startY+row*(bh+gap);if(x>=l&&x<=l+bw&&y>=t&&y<=t+bh)return i;}
        if(x>=w-d(112)&&x<=w-d(62)&&y<=d(58))return 21;
        if(x>=w-d(56)&&y<=d(58))return 22;
        if(x>=d(16)&&x<=d(120)&&y>=d(230)&&y<=d(292))return 23;
        if(x>=w-d(120)&&y>=d(230)&&y<=d(292))return 20;
        return -1;
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()==MotionEvent.ACTION_DOWN){downKey=hit(e.getX(),e.getY()); if(downKey>=0) vibrate(); invalidate(); return true;}
        if(e.getAction()==MotionEvent.ACTION_UP){int k=hit(e.getX(),e.getY()); if(k==22)tealTheme=!tealTheme; else if(k==21)showSettings(); else if(k==23)shareResult(); else if(k==20)showHistory(); else if(k>=0&&k==downKey)tap(k); downKey=-1; invalidate(); return true;}
        if(e.getAction()==MotionEvent.ACTION_CANCEL){downKey=-1;invalidate();return true;} return true;
    }
    private void vibrate(){ if(!vibration)return; try{ if(Build.VERSION.SDK_INT>=29)((android.os.Vibrator)getContext().getSystemService(Context.VIBRATOR_SERVICE)).vibrate(android.os.VibrationEffect.createOneShot(12,45)); else ((android.os.Vibrator)getContext().getSystemService(Context.VIBRATOR_SERVICE)).vibrate(12);}catch(Exception ignored){} }

    private void tap(int i){
        String k=keys[i];
        if(k.equals("AC")){value="0";expr="";preview="";evaluated=false;}
        else if(k.equals("⌫")){if(evaluated){value="0";expr="";evaluated=false;} else value=value.length()>1?value.substring(0,value.length()-1):"0";live();}
        else if(k.equals("=")){calculate();}
        else if(k.equals("±")){if(!value.equals("0"))value=value.startsWith("-")?value.substring(1):"-"+value;live();}
        else if(k.equals("%")){try{value=fmt(Double.parseDouble(value)/100.0);live();}catch(Exception ignored){}}
        else if("0123456789.".contains(k)){
            if(evaluated){value="0";expr="";evaluated=false;}
            if(k.equals(".")&&value.contains("."))return;
            value=(value.equals("0")&&!k.equals("."))?k:value+k;live();
        } else { appendOperator(k); }
    }

    private void appendOperator(String op){
        if(value.equals("Error")){value="0";expr="";}
        // Replace a trailing operator rather than creating invalid expressions.
        if(!expr.isEmpty() && (expr.endsWith(" + ")||expr.endsWith(" - ")||expr.endsWith(" × ")||expr.endsWith(" ÷ "))){
            expr=expr.substring(0,expr.length()-3)+" "+op+" ";
        } else {
            expr += value + " " + op + " ";
        }
        value="0"; evaluated=false; live();
    }

    private void live(){preview="";if(!expr.isEmpty()&&!value.equals("Error")){try{preview=fmt(Eval.go(expr+value));}catch(Exception ignored){}}invalidate();}
    private void calculate(){
        if(expr.isEmpty())return;
        try{
            String full=expr+value;
            String out=fmt(Eval.go(full));
            history.add(0,full+" = "+out); while(history.size()>50)history.remove(history.size()-1); save();
            value=out; preview=""; expr=full+" ="; evaluated=true;
        }catch(Exception x){value="Error";evaluated=true;}
        invalidate();
    }
    private void save(){StringBuilder b=new StringBuilder();for(String s:history)b.append(s).append("\n");sp.edit().putString("items",b.toString()).apply();}
    private String fmt(double x){if(Double.isInfinite(x)||Double.isNaN(x))throw new ArithmeticException();if(Math.abs(x-Math.rint(x))<1e-10)return Long.toString(Math.round(x));return String.format(Locale.US,"%.10f",x).replaceAll("0+$","").replaceAll("\\.$","");}
    private void shareResult(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,expr.isEmpty()?value:expr+value);getContext().startActivity(Intent.createChooser(i,"分享计算结果"));}

    private void showSettings(){
        final Dialog dialog=new Dialog(getContext());
        LinearLayout root=new LinearLayout(getContext()); root.setOrientation(LinearLayout.VERTICAL); root.setPadding((int)d(22),(int)d(20),(int)d(22),(int)d(16));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(22,25,42),tealTheme?Color.rgb(14,46,51):Color.rgb(45,27,63)}); bg.setCornerRadius(d(28)); root.setBackground(bg);
        TextView title=new TextView(getContext()); title.setText("设置"); title.setTextColor(Color.WHITE); title.setTextSize(22); title.setTypeface(Typeface.DEFAULT_BOLD); root.addView(title,new LinearLayout.LayoutParams(-1,(int)d(44)));
        TextView sub=new TextView(getContext()); sub.setText("个性化你的计算器体验"); sub.setTextColor(Color.rgb(145,153,177)); sub.setTextSize(13); root.addView(sub,new LinearLayout.LayoutParams(-1,(int)d(32)));
        LinearLayout row=new LinearLayout(getContext()); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding((int)d(14),0,(int)d(8),0); GradientDrawable rb=new GradientDrawable(); rb.setColor(0x221f243b); rb.setCornerRadius(d(17)); row.setBackground(rb);
        LinearLayout labels=new LinearLayout(getContext()); labels.setOrientation(LinearLayout.VERTICAL);
        TextView t=new TextView(getContext());t.setText("按键震动");t.setTextColor(Color.WHITE);t.setTextSize(16);t.setTypeface(Typeface.DEFAULT_BOLD);
        TextView st=new TextView(getContext());st.setText("点击数字和运算符时提供轻微触感");st.setTextColor(Color.rgb(140,148,171));st.setTextSize(12);labels.addView(t);labels.addView(st);
        row.addView(labels,new LinearLayout.LayoutParams(0,(int)d(64),1));
        Switch sw=new Switch(getContext()); sw.setChecked(vibration); sw.setButtonTintList(ColorStateList.valueOf(accent())); sw.setOnCheckedChangeListener((button,checked)->{vibration=checked;sp.edit().putBoolean("vibration",checked).apply();}); row.addView(sw,new LinearLayout.LayoutParams((int)d(58),(int)d(52)));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,(int)d(72));rp.setMargins(0,(int)d(10),0,(int)d(18));root.addView(row,rp);
        Button close=new Button(getContext()); close.setText("完成"); close.setTextColor(Color.WHITE); close.setOnClickListener(v->dialog.dismiss()); root.addView(close,new LinearLayout.LayoutParams(-1,(int)d(48)));
        dialog.setContentView(root); dialog.show(); if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));dialog.getWindow().setLayout((int)(getWidth()*.88),(int)(getHeight()*.45));}
    }

    private void showHistory(){
        final Dialog dialog=new Dialog(getContext());
        LinearLayout root=new LinearLayout(getContext());root.setOrientation(LinearLayout.VERTICAL);root.setPadding((int)d(20),(int)d(18),(int)d(20),(int)d(14));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(20,23,40),tealTheme?Color.rgb(13,47,53):Color.rgb(47,25,65)});bg.setCornerRadius(d(26));root.setBackground(bg);
        TextView title=new TextView(getContext());title.setText("计算记录  ·  "+history.size());title.setTextColor(Color.WHITE);title.setTextSize(22);title.setTypeface(Typeface.DEFAULT_BOLD);root.addView(title,new LinearLayout.LayoutParams(-1,(int)d(44)));
        ScrollView scroll=new ScrollView(getContext());LinearLayout list=new LinearLayout(getContext());list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(history.isEmpty()){TextView empty=new TextView(getContext());empty.setText("暂无计算记录");empty.setTextColor(Color.LTGRAY);empty.setTextSize(16);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,(int)d(120)));}
        else for(String s:history){TextView row=new TextView(getContext());row.setText(s);row.setTextColor(Color.WHITE);row.setTextSize(15);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding((int)d(15),0,(int)d(15),0);GradientDrawable rg=new GradientDrawable();rg.setColor(0x221c2138);rg.setCornerRadius(d(15));row.setBackground(rg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)d(52));lp.setMargins(0,0,0,(int)d(7));list.addView(row,lp);}
        Button close=new Button(getContext());close.setText("关闭");close.setOnClickListener(v->dialog.dismiss());root.addView(close,new LinearLayout.LayoutParams(-1,(int)d(48)));
        dialog.setContentView(root);dialog.show();if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));dialog.getWindow().setLayout((int)(getWidth()*.9),(int)(getHeight()*.78));}
    }
}

class Eval {
    static double go(String s){
        s=s.replace("×","*").replace("÷","/").replace("−","-").replaceAll("\\s+","");
        ArrayList<String> out=new ArrayList<>(), ops=new ArrayList<>();
        int i=0;
        while(i<s.length()){
            char ch=s.charAt(i);
            if(Character.isDigit(ch)||ch=='.'){
                int j=i+1; while(j<s.length()&&(Character.isDigit(s.charAt(j))||s.charAt(j)=='.'))j++;
                String n=s.substring(i,j); Double.parseDouble(n); out.add(n); i=j; continue;
            }
            String op=String.valueOf(ch);
            if((ch=='-' )&&(i==0 || "+-*/".indexOf(s.charAt(i-1))>=0)) op="u-";
            if(op.equals("("))ops.add(op);
            else if(op.equals(")")){while(!ops.isEmpty()&&!ops.get(ops.size()-1).equals("("))out.add(ops.remove(ops.size()-1));if(ops.isEmpty())throw new IllegalArgumentException();ops.remove(ops.size()-1);}
            else if("+-*/u-".contains(op)){
                while(!ops.isEmpty()&&!ops.get(ops.size()-1).equals("(")&&pr(ops.get(ops.size()-1))>=pr(op))out.add(ops.remove(ops.size()-1));ops.add(op);
            } else throw new IllegalArgumentException();
            i++;
        }
        while(!ops.isEmpty()){if(ops.get(ops.size()-1).equals("("))throw new IllegalArgumentException();out.add(ops.remove(ops.size()-1));}
        Stack<Double> st=new Stack<>();
        for(String a:out){if(a.matches("[0-9.]+"))st.push(Double.parseDouble(a));else if(a.equals("u-")){if(st.isEmpty())throw new IllegalArgumentException();st.push(-st.pop());}else{if(st.size()<2)throw new IllegalArgumentException();double b=st.pop(),aa=st.pop();if(a.equals("/")&&b==0)throw new ArithmeticException();st.push(a.equals("+")?aa+b:a.equals("-")?aa-b:a.equals("*")?aa*b:aa/b);}}
        if(st.size()!=1)throw new IllegalArgumentException();return st.pop();
    }
    static int pr(String s){return s.equals("u-")?3:(s.equals("+")||s.equals("-"))?1:2;}
}
