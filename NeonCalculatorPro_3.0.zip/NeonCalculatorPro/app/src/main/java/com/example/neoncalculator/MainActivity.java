package com.example.neoncalculator;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import android.text.TextUtils;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(9, 10, 18));
        w.setNavigationBarColor(Color.rgb(9, 10, 18));
        if (Build.VERSION.SDK_INT >= 30) w.setDecorFitsSystemWindows(true);
        if (Build.VERSION.SDK_INT >= 23) w.getDecorView().setSystemUiVisibility(0);
        setContentView(new CalculatorView(this));
    }
}

class CalculatorView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final String[] keys = {"AC","⌫","%","÷","7","8","9","×","4","5","6","−","1","2","3","+","±","0",".","="};
    private String value = "0", expr = "", preview = "";
    private boolean evaluated = false;
    private boolean tealTheme = false;
    private int downKey = -1;
    private final ArrayList<String> history = new ArrayList<>();
    private final SharedPreferences sp;
    private float den;

    CalculatorView(Context c) {
        super(c);
        den = getResources().getDisplayMetrics().density;
        setFocusable(true);
        sp = c.getSharedPreferences("calculator_history", Context.MODE_PRIVATE);
        String saved = sp.getString("items", "");
        if (!TextUtils.isEmpty(saved)) history.addAll(Arrays.asList(saved.split("\\n")));
    }

    private float d(float x) { return x * den; }
    private int accent() { return tealTheme ? Color.rgb(44, 211, 205) : Color.rgb(174, 104, 255); }
    private int accent2() { return tealTheme ? Color.rgb(31, 133, 190) : Color.rgb(108, 64, 205); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w = getWidth(), h = getHeight();
        drawBackground(c, w, h);

        // Header
        p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        p.setTextSize(d(22)); p.setColor(Color.WHITE);
        c.drawText("CALCULATOR", d(20), d(34), p);
        p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        p.setTextSize(d(11)); p.setColor(Color.rgb(148, 155, 180));
        c.drawText("PRO  •  SIMPLE  •  FAST", d(21), d(52), p);
        drawSmallButton(c, w-d(70), d(18), w-d(18), d(50), "主题");

        // Display
        float top = d(68), left = d(16), right = w-d(16), bottom = d(224);
        roundPanel(c, left, top, right, bottom, d(24), Color.rgb(19,22,39), Color.rgb(51,56,82));
        p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        p.setTextSize(d(14)); p.setColor(Color.rgb(133,141,170));
        String shownExpr = expr.length() > 30 ? "…" + expr.substring(expr.length()-29) : expr;
        c.drawText(shownExpr, left+d(18), top+d(31), p);

        drawSmallButton(c, right-d(74), top+d(12), right-d(12), top+d(44), "分享");
        p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        p.setTextSize(d(value.length() > 12 ? 31 : 43)); p.setColor(Color.WHITE);
        String shownValue = value.length() > 16 ? value.substring(0,16) : value;
        float vw = p.measureText(shownValue);
        c.drawText(shownValue, right-d(18)-vw, bottom-d(48), p);
        if (!preview.isEmpty()) {
            p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); p.setTextSize(d(13)); p.setColor(accent());
            String pv = "≈ " + preview; float pw = p.measureText(pv);
            c.drawText(pv, right-d(18)-pw, bottom-d(20), p);
        }

        // Recent result strip
        float recentY = d(238);
        roundPanel(c, left, recentY, right, recentY+d(52), d(17), Color.rgb(15,18,32), Color.rgb(40,45,68));
        p.setTextSize(d(12)); p.setColor(Color.rgb(130,138,164)); p.setTypeface(Typeface.DEFAULT);
        c.drawText("最近计算", left+d(15), recentY+d(20), p);
        String recent = history.isEmpty() ? "暂无记录" : history.get(0);
        p.setTextSize(d(13)); p.setColor(Color.WHITE); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        if (recent.length()>29) recent = "…" + recent.substring(recent.length()-28);
        c.drawText(recent, left+d(15), recentY+d(39), p);

        // Keypad
        float gap = d(8), startY = d(304), bw = (w-d(32)-gap*3)/4f, bh = d(58);
        for (int i=0;i<20;i++) {
            int row=i/4, col=i%4;
            float x=d(16)+col*(bw+gap), y=startY+row*(bh+gap);
            drawKey(c,x,y,x+bw,y+bh,keys[i],i);
        }
        float historyY = startY + 5*(bh+gap);
        roundPanel(c,left,historyY,right,historyY+bh,d(18),Color.rgb(19,22,39),Color.rgb(53,59,87));
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(d(14)); p.setColor(Color.WHITE);
        c.drawText("查看全部计算记录  ·  " + history.size(), w/2f, historyY+d(36), p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    private void drawBackground(Canvas c,int w,int h) {
        int bg = tealTheme ? Color.rgb(8,16,22) : Color.rgb(12,10,22);
        c.drawColor(bg);
        p.setShader(new LinearGradient(0,0,w,h,tealTheme?Color.rgb(10,33,42):Color.rgb(30,15,51),bg,Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p); p.setShader(null);
        // Subtle fixed accents: no animation, no frame loop.
        p.setColor(tealTheme ? 0x1428d5cf : 0x18a86cff); c.drawCircle(w-d(5),h-d(70),d(105),p);
        p.setColor(tealTheme ? 0x0e4d8aff : 0x101e5cff); c.drawCircle(d(10),d(300),d(80),p);
        p.setColor(0x12ffffff);
        for(int i=0;i<14;i++) c.drawCircle((i*83+29)%w, d(90)+(i*97)%(Math.max(1,h-(int)d(100))), d(1.2f), p);
    }

    private void roundPanel(Canvas c,float l,float t,float r,float b,float rad,int fill,int edge) {
        p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(l,t,r,b,rad,rad,p);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(d(1)); stroke.setColor(edge); c.drawRoundRect(l,t,r,b,rad,rad,stroke);
    }

    private void drawSmallButton(Canvas c,float l,float t,float r,float b,String s) {
        roundPanel(c,l,t,r,b,d(16),tealTheme?Color.rgb(18,49,56):Color.rgb(42,27,65),accent());
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(d(12)); p.setColor(Color.WHITE);
        c.drawText(s,(l+r)/2,(t+b)/2-d(4)+d(4),p); p.setTextAlign(Paint.Align.LEFT);
    }

    private void drawKey(Canvas c,float l,float t,float r,float b,String s,int idx) {
        boolean op = idx%4==3, equals=s.equals("="), danger=s.equals("AC")||s.equals("⌫");
        int fill = Color.rgb(24,28,48), edge = Color.rgb(55,62,91);
        if(op) { fill=tealTheme?Color.rgb(17,55,65):Color.rgb(46,30,68); edge=accent(); }
        if(equals) { fill=accent2(); edge=accent(); }
        if(danger) { fill=Color.rgb(53,30,46); edge=Color.rgb(201,86,147); }
        if(idx==downKey) { fill = Color.rgb(Math.min(255,Color.red(fill)+18),Math.min(255,Color.green(fill)+18),Math.min(255,Color.blue(fill)+18)); }
        roundPanel(c,l,t,r,b,d(18),fill,edge);
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(d(21)); p.setColor(Color.WHITE);
        c.drawText(s,(l+r)/2,(t+b)/2-d(7)+d(7),p); p.setTextAlign(Paint.Align.LEFT);
    }

    private int hit(float x,float y) {
        int w=getWidth(); float gap=d(8), startY=d(304), bw=(w-d(32)-gap*3)/4f, bh=d(58);
        for(int i=0;i<20;i++){int row=i/4,col=i%4;float l=d(16)+col*(bw+gap),t=startY+row*(bh+gap);if(x>=l&&x<=l+bw&&y>=t&&y<=t+bh)return i;}
        float hy=startY+5*(bh+gap); if(y>=hy&&y<=hy+bh)return 20;
        if(x>=w-d(78)&&y>=d(68)&&y<=d(125))return 21;
        if(x>=w-d(78)&&y<=d(60))return 22;
        return -1;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction()==MotionEvent.ACTION_DOWN){ downKey=hit(e.getX(),e.getY()); invalidate(); return true; }
        if(e.getAction()==MotionEvent.ACTION_UP){
            int k=hit(e.getX(),e.getY());
            if(k==22){ tealTheme=!tealTheme; }
            else if(k==21){ shareResult(); }
            else if(k==20){ showHistory(); }
            else if(k>=0 && k==downKey){ tap(k); }
            downKey=-1; invalidate(); return true;
        }
        if(e.getAction()==MotionEvent.ACTION_CANCEL){downKey=-1;invalidate();return true;}
        return true;
    }

    private void tap(int i){
        String k=keys[i];
        if(k.equals("AC")){value="0";expr="";preview="";evaluated=false;}
        else if(k.equals("⌫")){value=value.length()>1?value.substring(0,value.length()-1):"0";live();}
        else if(k.equals("=")){calculate();}
        else if(k.equals("±")){if(!value.equals("0"))value=value.startsWith("-")?value.substring(1):"-"+value;live();}
        else if(k.equals("%")){try{value=fmt(Double.parseDouble(value)/100);live();}catch(Exception ignored){}}
        else if("0123456789.".contains(k)){if(evaluated){value="0";expr="";evaluated=false;}if(k.equals(".")&&value.contains("."))return;value=(value.equals("0")&&!k.equals("."))?k:value+k;live();}
        else {expr=value+" "+k+" ";value="0";evaluated=false;live();}
    }

    private void live(){preview="";if(!expr.isEmpty()&&!value.equals("Error")){try{preview=fmt(Eval.go(expr+value));}catch(Exception ignored){}}invalidate();}
    private void calculate(){if(expr.isEmpty())return;try{String full=expr+value;String out=fmt(Eval.go(full));history.add(0,full+" = "+out);while(history.size()>50)history.remove(history.size()-1);save();value=out;preview="";expr=full+" =";evaluated=true;}catch(Exception x){value="Error";evaluated=true;}invalidate();}
    private void save(){StringBuilder b=new StringBuilder();for(String s:history)b.append(s).append("\n");sp.edit().putString("items",b.toString()).apply();}
    private String fmt(double x){if(Double.isInfinite(x)||Double.isNaN(x))throw new ArithmeticException();if(Math.abs(x-Math.rint(x))<1e-10)return Long.toString(Math.round(x));return String.format(Locale.US,"%.10f",x).replaceAll("0+$","").replaceAll("\\.$","");}
    private void copyResult(){android.content.ClipboardManager cm=(android.content.ClipboardManager)getContext().getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("计算结果",value));Toast.makeText(getContext(),"已复制结果",Toast.LENGTH_SHORT).show();}
    private void shareResult(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,expr.isEmpty()?value:expr+value);getContext().startActivity(Intent.createChooser(i,"分享计算结果"));}

    private void showHistory(){
        final Dialog dialog=new Dialog(getContext());
        LinearLayout root=new LinearLayout(getContext());root.setOrientation(LinearLayout.VERTICAL);root.setPadding((int)d(20),(int)d(18),(int)d(20),(int)d(14));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(20,23,40),tealTheme?Color.rgb(13,47,53):Color.rgb(47,25,65)});bg.setCornerRadius(d(26));root.setBackground(bg);
        TextView title=new TextView(getContext());title.setText("计算记录  ·  "+history.size());title.setTextColor(Color.WHITE);title.setTextSize(22);title.setTypeface(Typeface.DEFAULT_BOLD);root.addView(title,new LinearLayout.LayoutParams(-1,(int)d(44)));
        ScrollView scroll=new ScrollView(getContext());LinearLayout list=new LinearLayout(getContext());list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(history.isEmpty()){TextView empty=new TextView(getContext());empty.setText("暂无计算记录");empty.setTextColor(Color.LTGRAY);empty.setTextSize(16);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,(int)d(120)));}
        else for(String s:history){TextView row=new TextView(getContext());row.setText(s);row.setTextColor(Color.WHITE);row.setTextSize(15);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding((int)d(15),0,(int)d(15),0);GradientDrawable rg=new GradientDrawable();rg.setColor(0x221c2138);rg.setCornerRadius(d(15));row.setBackground(rg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)d(52));lp.setMargins(0,0,0,(int)d(7));list.addView(row,lp);}
        Button close=new Button(getContext());close.setText("关闭");close.setOnClickListener(v->dialog.dismiss());root.addView(close,new LinearLayout.LayoutParams(-1,(int)d(48)));
        dialog.setContentView(root);Window win=dialog.getWindow();if(win!=null){win.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));win.setLayout((int)(getWidth()*.9),(int)(getHeight()*.78));}dialog.show();if(dialog.getWindow()!=null)dialog.getWindow().setLayout((int)(getWidth()*.9),(int)(getHeight()*.78));
    }
}

class Eval{
 static double go(String s){s=s.replace("×","*").replace("÷","/").replace("−","-");ArrayList<String> out=new ArrayList<>(),ops=new ArrayList<>();StringTokenizer z=new StringTokenizer(s,"+-*/()",true);while(z.hasMoreTokens()){String a=z.nextToken().trim();if(a.isEmpty())continue;if(a.matches("[0-9.]+"))out.add(a);else if(a.equals("("))ops.add(a);else if(a.equals(")")){while(!ops.isEmpty()&&!ops.get(ops.size()-1).equals("("))out.add(ops.remove(ops.size()-1));if(ops.isEmpty())throw new IllegalArgumentException();ops.remove(ops.size()-1);}else{while(!ops.isEmpty()&&!ops.get(ops.size()-1).equals("(")&&pr(ops.get(ops.size()-1))>=pr(a))out.add(ops.remove(ops.size()-1));ops.add(a);}}while(!ops.isEmpty()){if(ops.get(ops.size()-1).equals("("))throw new IllegalArgumentException();out.add(ops.remove(ops.size()-1));}Stack<Double> st=new Stack<>();for(String a:out)if(a.matches("[0-9.]+"))st.push(Double.parseDouble(a));else{if(st.size()<2)throw new IllegalArgumentException();double b=st.pop(),aa=st.pop();if(a.equals("/")&&b==0)throw new ArithmeticException();st.push(a.equals("+")?aa+b:a.equals("-")?aa-b:a.equals("*")?aa*b:aa/b);}if(st.size()!=1)throw new IllegalArgumentException();return st.pop();}
 static int pr(String s){return s.equals("+")||s.equals("-")?1:2;}
}
