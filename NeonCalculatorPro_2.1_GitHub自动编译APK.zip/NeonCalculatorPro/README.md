# 霓虹计算器 Pro 2.1

本版本在 2.0 基础上加入用户指定的 2/3/4/5/6：

2. 历史记录支持**向左滑动删除单条记录**；长按 HIST 清空全部记录。
3. **长按计算结果区域复制结果**到剪贴板。
4. 显示屏右上角增加**分享计算结果**，可调用手机系统分享菜单。
5. **主题切换 + 动态粒子星尘背景**，青蓝/紫色两套霓虹主题。
6. 增加**启动 Logo 动画**，进入计算器前显示霓虹启动效果。

同时保留：四则运算、百分比、正负号、小数、退格、实时预览、最多 50 条本地历史记录。

## 构建
用 Android Studio 打开本项目，等待 Gradle 同步，然后选择 Build -> Build APK(s)。

## GitHub 自动编译 APK

本项目已加入 `.github/workflows/build-apk.yml`。

上传到 GitHub 后：
1. 打开仓库的 **Actions**。
2. 选择 **Build Android APK**。
3. 点击 **Run workflow**（如果代码已经推送到 main/master，也会自动触发）。
4. 等待构建完成。
5. 打开成功的 workflow 运行记录，在 **Artifacts** 下载 `NeonCalculatorPro-debug-apk`。
6. 解压后即可得到 `app-debug.apk`，安装到 Android 手机。

说明：这是 Debug APK，适合测试和自己安装。以后如果要发布到应用商店，再增加正式签名配置。
