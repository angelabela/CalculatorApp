package com.example.neoncalculator;

import android.app.*;
import android.os.*;
import android.content.*;
import android.text.TextUtils;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.animation.OvershootInterpolator;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,9,20)); getWindow().setNavigationBarColor(Color.rgb(7,9,20));
        final FrameLayout splash=new FrameLayout(this); splash.setBackgroundColor(Color.rgb(7,9,20));
        final TextView logo=new TextView(this); logo.setText("✦\nNEON\nCALCULATOR"); logo.setGravity(Gravity.CENTER); logo.setTextColor(Color.WHITE); logo.setTextSize(32); logo.setTypeface(Typeface.DEFAULT_BOLD);
        logo.setShadowLayer(28,0,0,0xffb54cff); splash.addView(logo,new FrameLayout.LayoutParams(-1,-1)); setContentView(splash);
        logo.setAlpha(0f); logo.setScaleX(.65f); logo.setScaleY(.65f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).setInterpolator(new OvershootInterpolator()).withEndAction(()->new Handler().postDelayed(()->setContentView(new NeonCalculator(this)),350)).start();
    }
}

class NeonCalculator extends View {
    Paint p=new Paint(Paint.ANTI_ALIAS_FLAG), glow=new Paint(Paint.ANTI_ALIAS_FLAG);
    String value="0", expr="", preview=""; boolean evaluated=false, violet=true;
    ArrayList<String> history=new ArrayList<>(); SharedPreferences sp;
    Random rnd=new Random(7); ArrayList<Star> stars=new ArrayList<>(); long lastFrame;
    String[] keys={"AC","⌫","%","÷","7","8","9","×","4","5","6","−","1","2","3","+","±","0",".","="};
    float downX,downY; int downKey=-1; long downTime;
    NeonCalculator(Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); sp=c.getSharedPreferences("neon_history",0); String s=sp.getString("items",""); if(!s.isEmpty()) history.addAll(Arrays.asList(s.split("\\n"))); for(int i=0;i<55;i++) stars.add(new Star(rnd.nextFloat(),rnd.nextFloat(),.4f+rnd.nextFloat()*1.8f)); }
    float d(float x){return x*getResources().getDisplayMetrics().density;}
    @Override protected void onDraw(Canvas c){
        int w=getWidth(),h=getHeight();
        int a=Color.rgb(5,8,20), b=violet?Color.rgb(31,7,52):Color.rgb(5,33,48);
        p.setShader(new LinearGradient(0,0,w,h,a,b,Shader.TileMode.CLAMP)); c.drawRect(0,0,w,h,p); p.setShader(null);
        drawNebula(c,w,h); drawStars(c,w,h);
        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(d(23)); p.setColor(Color.WHITE); c.drawText("NEON",d(20),d(38),p);
        p.setTextSize(d(11)); p.setColor(violet?0xffd49cff:0xff70e9ff); c.drawText("CALCULATOR PRO  ·  2.0",d(21),d(55),p);
        // theme button
        circleButton(c,w-d(44),d(32),violet?0xffa855f7:0xff22d3ee);
        // display glass
        float L=d(15),T=d(70),R=w-d(15),B=d(235); glass(c,L,T,R,B);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(d(14)); p.setColor(0xff8994b8); c.drawText(expr,L+d(20),T+d(32),p); pill(c,R-d(78),T+d(12),R-d(12),T+d(43),"↗ 分享",0x331b2444,violet?0xffb45cff:0xff27d8ff);
        p.setTextSize(value.length()>13?d(29):d(43)); p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(value,L+d(20),B-d(47),p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(d(16)); p.setColor(violet?0xffe7c8ff:0xffa8f2ff); if(!preview.isEmpty()) c.drawText("≈ "+preview,R-d(25)-p.measureText("≈ "+preview),B-d(18),p);
        // history pill
        pill(c,d(16),d(250),w-d(16),d(290),"☷   HISTORY  ·  "+history.size(),0xff171a35,violet?0xffb45cff:0xff27d8ff);
        // keypad
        float gap=d(9), sy=d(305), bw=(w-d(30)-gap*3)/4f, bh=d(60);
        for(int i=0;i<20;i++){int r=i/4,col=i%4;float x=d(15)+col*(bw+gap),y=sy+r*(bh+gap); drawKey(c,x,y,x+bw,y+bh,keys[i],i);}
        float fy=sy+5*(bh+gap); pill(c,d(15),fy,w-d(15),fy+bh,"☷  查看全部计算记录",0xff171a35,0xff9d5cff);
        // particles animate
        if(System.currentTimeMillis()-lastFrame>16){ lastFrame=System.currentTimeMillis(); for(Star s:stars){s.y-=0.00055f*s.speed; if(s.y<0)s.y=1;} postInvalidateDelayed(16); }
    }
    void drawNebula(Canvas c,int w,int h){p.setAlpha(30);p.setColor(violet?0xffb000ff:0xff00d9ff);c.drawCircle(w*.15f,h*.30f,d(125),p);p.setColor(violet?0xff00d9ff:0xff0088ff);c.drawCircle(w*.88f,h*.72f,d(170),p);p.setAlpha(255);}
    void drawStars(Canvas c,int w,int h){for(Star s:stars){p.setColor(violet?0xffc9b5ff:0xffa5efff);p.setAlpha((int)(35+80*s.speed/2));c.drawCircle(s.x*w,s.y*h,d(s.speed),p);}p.setAlpha(255);}
    void glass(Canvas c,float l,float t,float r,float b){p.setColor(0x9910152d);p.setShadowLayer(d(18),0,0,violet?0xff9d4edd:0xff16cbe5);c.drawRoundRect(l,t,r,b,d(26),d(26),p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(1.5f));p.setColor(violet?0xff8d5bd8:0xff25cce9);c.drawRoundRect(l,t,r,b,d(26),d(26),p);p.setStyle(Paint.Style.FILL);}
    void pill(Canvas c,float l,float t,float r,float b,String s,int fill,int edge){p.setColor(fill);p.setShadowLayer(d(7),0,0,edge);c.drawRoundRect(l,t,r,b,d(18),d(18),p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setColor(edge);p.setStrokeWidth(d(1));c.drawRoundRect(l,t,r,b,d(18),d(18),p);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTextSize(d(14));float tw=p.measureText(s);c.drawText(s,(l+r-tw)/2,(t+b)/2-p.ascent()/2-p.descent()/2,p);}
    void circleButton(Canvas c,float x,float y,int col){p.setColor(0x33111122);c.drawCircle(x,y,d(20),p);p.setColor(col);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(2));c.drawCircle(x,y,d(13),p);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(x,y,d(4),p);}
    void drawKey(Canvas c,float l,float t,float r,float b,String s,int idx){int fill=0xff151a34,edge=0xff4b5880;if(idx%4==3){fill=0xff103b4d;edge=violet?0xff24d7ff:0xff5ee7ff;}if(s.equals("=")){fill=violet?0xff64188e:0xff075a75;edge=violet?0xffff4fda:0xff3ff7ff;}if(s.equals("AC")||s.equals("⌫")){fill=0xff431d3b;edge=0xffff5a9f;}if(downKey==idx){fill=violet?0xff8235a9:0xff116d82;}p.setColor(fill);p.setShadowLayer(d(9),0,0,edge);c.drawRoundRect(l,t,r,b,d(18),d(18),p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(1.2f));p.setColor(edge);c.drawRoundRect(l,t,r,b,d(18),d(18),p);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(d(21));float tw=p.measureText(s);c.drawText(s,(l+r-tw)/2,(t+b)/2-p.ascent()/2-p.descent()/2,p);p.setTypeface(Typeface.DEFAULT);}
    int hit(float x,float y){int w=getWidth();float gap=d(9),sy=d(305),bw=(w-d(30)-gap*3)/4f,bh=d(60);for(int i=0;i<20;i++){int r=i/4,col=i%4;float l=d(15)+col*(bw+gap),t=sy+r*(bh+gap);if(x>=l&&x<=l+bw&&y>=t&&y<=t+bh)return i;}float fy=sy+5*(bh+gap);if(y>=fy&&y<=fy+bh)return 20;if(x>getWidth()-d(82)&&y>=d(72)&&y<=d(125))return 22;if(x>getWidth()-d(70)&&y<d(65))return 21;if(y>=d(250)&&y<=d(290))return 20;return -1;}
    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();downKey=hit(downX,downY);downTime=System.currentTimeMillis();invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP){int k=hit(e.getX(),e.getY());boolean longPress=System.currentTimeMillis()-downTime>650;if(k==20&&longPress){clearHistory();}else if(k==20){showHistory();}else if(k==21){violet=!violet;invalidate();}else if(k==22){shareResult();}else if(longPress && downY>=d(70)&&downY<=d(235)){copyResult();}else if(k>=0&&k==downKey){tap(k);}downKey=-1;invalidate();return true;}return true;}
    void tap(int i){if(i>=0&&i<20){String k=keys[i];if(k.equals("AC")){value="0";expr="";preview="";evaluated=false;}else if(k.equals("⌫")){value=value.length()>1?value.substring(0,value.length()-1):"0";live();}else if(k.equals("=")){calculate();}else if(k.equals("±")){if(!value.equals("0"))value=value.startsWith("-")?value.substring(1):"-"+value;live();}else if(k.equals("%")){try{value=fmt(Double.parseDouble(value)/100);live();}catch(Exception ignored){}}else if("0123456789.".contains(k)){if(evaluated){value="0";expr="";evaluated=false;}if(k.equals(".")&&value.contains("."))return;value=(value.equals("0")&&!k.equals("."))?k:value+k;live();}else{expr=value+" "+k+" ";value="0";evaluated=false;live();}animateClick();}}
    void live(){preview="";if(!expr.isEmpty()&&!value.equals("Error")){try{preview=fmt(Eval.go(expr+value));}catch(Exception ignored){}}invalidate();}
    void calculate(){if(expr.isEmpty())return;try{String full=expr+value;String out=fmt(Eval.go(full));history.add(0,full+" = "+out);while(history.size()>50)history.remove(history.size()-1);save();value=out;preview="";expr=full+" =";evaluated=true;animate().scaleX(.97f).scaleY(.97f).setDuration(90).withEndAction(()->animate().scaleX(1).scaleY(1).setDuration(220).setInterpolator(new OvershootInterpolator()).start()).start();}catch(Exception x){value="Error";evaluated=true;}invalidate();}
    void save(){StringBuilder b=new StringBuilder();for(String s:history)b.append(s).append("\n");sp.edit().putString("items",b.toString()).apply();}
    void clearHistory(){history.clear();save();invalidate();}
    String fmt(double x){if(Double.isInfinite(x)||Double.isNaN(x))throw new ArithmeticException();if(Math.abs(x-Math.rint(x))<1e-10)return Long.toString(Math.round(x));return String.format(Locale.US,"%.10f",x).replaceAll("0+$","").replaceAll("\\.$","");}
    void animateClick(){setScaleX(.992f);setScaleY(.992f);animate().scaleX(1).scaleY(1).setDuration(130).start();}
    void copyResult(){
        ClipboardManager cm=(ClipboardManager)getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("计算结果",value));
        Toast.makeText(getContext(),"已复制结果："+value,Toast.LENGTH_SHORT).show();
    }
    void shareResult(){
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,expr.isEmpty()?value:expr+" "+value+" = "+value);
        getContext().startActivity(Intent.createChooser(i,"分享计算结果"));
    }
    void showHistory(){
        final Dialog q=new Dialog(getContext()); LinearLayout root=new LinearLayout(getContext()); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,22,24,18);
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff10152f,violet?0xff3b0a4b:0xff073d4c}); g.setCornerRadius(40); root.setBackground(g);
        TextView title=new TextView(getContext()); title.setText("计算记录  ·  "+history.size()); title.setTextColor(Color.WHITE); title.setTextSize(24); title.setTypeface(Typeface.DEFAULT_BOLD); root.addView(title);
        ScrollView sv=new ScrollView(getContext()); LinearLayout list=new LinearLayout(getContext()); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0,10,0,15);
        if(history.isEmpty()){ TextView empty=new TextView(getContext()); empty.setText("还没有计算记录\n\n提示：向左滑动可删除单条记录"); empty.setTextColor(0xffcbd3ee); empty.setTextSize(16); list.addView(empty); }
        else buildHistoryRows(list,title);
        sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        Button close=new Button(getContext()); close.setText("关闭"); close.setOnClickListener(v->q.dismiss()); root.addView(close);
        q.setContentView(root); q.show(); Window w=q.getWindow(); if(w!=null){w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT)); w.setLayout((int)(getWidth()*.9),(int)(getHeight()*.76));}
    }
    void buildHistoryRows(LinearLayout list, TextView title){
        for(int i=0;i<history.size();i++){
            final int pos=i; TextView row=new TextView(getContext()); row.setText(history.get(i)); row.setTextColor(Color.WHITE); row.setTextSize(16); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(18,4,18,4);
            GradientDrawable rg=new GradientDrawable(); rg.setColor(0x221b2342); rg.setCornerRadius(d(18)); row.setBackground(rg);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,(int)d(62)); lp.setMargins(0,0,0,(int)d(8)); list.addView(row,lp);
            row.setOnTouchListener(new View.OnTouchListener(){float sx; public boolean onTouch(View v,MotionEvent ev){ if(ev.getAction()==MotionEvent.ACTION_DOWN){sx=ev.getX();return true;} if(ev.getAction()==MotionEvent.ACTION_UP){float dx=ev.getX()-sx; if(dx<-d(80)){history.remove(pos);save(); list.removeView(v); title.setText("计算记录  ·  "+history.size()); Toast.makeText(getContext(),"已删除记录",Toast.LENGTH_SHORT).show();} return true;} return true; }});
        }
    }
    static class Star{float x,y,speed;Star(float x,float y,float s){this.x=x;this.y=y;this.speed=s;}}
}
class Eval{
 static double go(String s){s=s.replace("×","*").replace("÷","/").replace("−","-");ArrayList<String> out=new ArrayList<>(),ops=new ArrayList<>();StringTokenizer z=new StringTokenizer(s,"+-*/()",true);while(z.hasMoreTokens()){String a=z.nextToken().trim();if(a.isEmpty())continue;if(a.matches("[0-9.]+"))out.add(a);else if(a.equals("("))ops.add(a);else if(a.equals(")")){while(!ops.isEmpty()&&!ops.get(ops.size()-1).equals("("))out.add(ops.remove(ops.size()-1));if(ops.isEmpty())throw new IllegalArgumentException();ops.remove(ops.size()-1);}else{while(!ops.isEmpty()&&!ops.get(ops.size()-1).equals("(")&&pr(ops.get(ops.size()-1))>=pr(a))out.add(ops.remove(ops.size()-1));ops.add(a);}}while(!ops.isEmpty()){if(ops.get(ops.size()-1).equals("("))throw new IllegalArgumentException();out.add(ops.remove(ops.size()-1));}Stack<Double> st=new Stack<>();for(String a:out)if(a.matches("[0-9.]+"))st.push(Double.parseDouble(a));else{if(st.size()<2)throw new IllegalArgumentException();double b=st.pop(),aa=st.pop();if(a.equals("/")&&b==0)throw new ArithmeticException();st.push(a.equals("+")?aa+b:a.equals("-")?aa-b:a.equals("*")?aa*b:aa/b);}if(st.size()!=1)throw new IllegalArgumentException();return st.pop();}
 static int pr(String s){return s.equals("+")||s.equals("-")?1:2;}
}
